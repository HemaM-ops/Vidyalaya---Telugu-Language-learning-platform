import torch
import torchaudio
from transformers import Wav2Vec2Processor, Wav2Vec2ForCTC
import sounddevice as sd
import numpy as np
from scipy.io.wavfile import write
import gradio as gr
import re
import queue
import threading
import requests
import json
from difflib import SequenceMatcher
import matplotlib.pyplot as plt
from PIL import Image
import io
import base64
from gtts import gTTS
import os

# Load the Telugu ASR model and processor
model_name = "Harveenchadha/vakyansh-wav2vec2-telugu-tem-100"
processor = Wav2Vec2Processor.from_pretrained(model_name)
model = Wav2Vec2ForCTC.from_pretrained(model_name)

# Mistral API configuration
MISTRAL_API_KEY = "K2o8ftBzqtPID5cPRjRhrSW6vA6cs7zl"  # Replace with your actual API key

# Parameters
SAMPLE_RATE = 16000
audio_queue = queue.Queue()
is_recording = False

class TeluguGrammarAnalyzer:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.mistral.ai/v1/chat/completions"
        
        self.few_shot_examples = [
            {
                "incorrect": "నాకు తెలుగు మాట్లాడలేను",
                "correct": "నాకు తెలుగు మాట్లాడటం రాదు",
                "explanation": "క్రియా రూపంలో తప్పు. 'మాట్లాడలేను' కాకుండా 'మాట్లాడటం రాదు' అని సరిగ్గా వాడాలి.",
                "pronunciation": "Focus on clear articulation of 'మాట్లాడటం' (maaṭ-lā-da-ṭaṁ)"
            },
            {
                "incorrect": "అతను బడికి వెళ్లాడు",
                "correct": "అతను బడికి వెళ్లాడు",
                "explanation": "సరైన వాక్యం. 'బడికి' అనేది సరైన సందర్భంలో ఉంది.",
                "pronunciation": "Good pronunciation of 'వెళ్లాడు' (veḷ-lā-du)"
            },
            {
                "incorrect": "మా అమ్మ మంచి ఉడుతున్నారు",
                "correct": "మా అమ్మ మంచి వండుతున్నారు",
                "explanation": "క్రియా పదం తప్పు. 'ఉడుతున్నారు' కాకుండా 'వండుతున్నారు' అని సరిగ్గా వాడాలి.",
                "pronunciation": "Emphasize the 'వం' (vaṁ) sound in 'వండుతున్నారు'"
            }
        ]
        
        self.one_shot_example = {
            "pattern": "Subject + Object + Verb (కర్త + కర్మ + క్రియా)",
            "example": "రాము పుస్తకం చదివాడు",
            "explanation": "తెలుగు వాక్య నిర్మాణం సాధారణంగా కర్త, కర్మ, క్రియా క్రమంలో ఉంటుంది.",
            "pronunciation": "Clear enunciation of each word is important"
        }

    def analyze(self, text):
        """Main analysis function with error handling"""
        if not text.strip():
            return self._create_error_response("Empty input")
            
        try:
            api_response = self._call_mistral_api_with_examples(text)
            response = self._parse_api_response(api_response)
            return self._format_response(text, response)
        except Exception as e:
            return self._create_error_response(f"Analysis failed: {str(e)}")

    def _call_mistral_api_with_examples(self, text):
        """Call Mistral API with few-shot examples"""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        examples_str = "\n".join(
            f"ఉదాహరణ {i+1}:\n"
            f"తప్పు వాక్యం: {ex['incorrect']}\n"
            f"సరిదిద్దిన వాక్యం: {ex['correct']}\n"
            f"వివరణ: {ex['explanation']}\n"
            f"ఉచ్చారణ సూచన: {ex['pronunciation']}\n"
            for i, ex in enumerate(self.few_shot_examples))
        
        prompt = f"""
        మీరు తెలుగు భాషా నిపుణులు. దయచేసి ఈ క్రింది వాక్యాన్ని విశ్లేషించండి, సరిదిద్దండి మరియు ఉచ్చారణ సూచనలు ఇవ్వండి.

        ### తెలుగు వ్యాకరణ నియమాల ఉదాహరణలు:
        {examples_str}

        ### ఒక ముఖ్యమైన నమూనా:
        నమూనా: {self.one_shot_example['pattern']}
        ఉదాహరణ: {self.one_shot_example['example']}
        వివరణ: {self.one_shot_example['explanation']}
        ఉచ్చారణ: {self.one_shot_example['pronunciation']}

        ### విశ్లేషించాల్సిన వాక్యం:
        "{text}"

        దయచేసి ఈ క్రింది JSON ఫార్మాట్‌లో జవాబు ఇవ్వండి:
        {{
            "corrected": "సరిదిద్దిన వాక్యం",
            "english_explanation": "వ్యాకరణ తప్పుల వివరణ ఇంగ్లీషులో",
            "telugu_explanation": "వ్యాకరణ తప్పుల వివరణ తెలుగులో",
            "pronunciation_guide": "ఉచ్చారణ సూచనలు",
            "errors": ["తప్పు 1", "తప్పు 2"],
            "error_types": ["వాక్య నిర్మాణం", "క్రియా రూపం"]
        }}
        """
        
        payload = {
            "model": "mistral-medium",
            "messages": [
                {"role": "system", "content": "మీరు తెలుగు భాషా నిపుణులు. దయచేసి ఖచ్చితమైన JSON రెస్పాన్స్‌ను మాత్రమే ఇవ్వండి."},
                {"role": "user", "content": prompt}
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0.2
        }
        
        try:
            response = requests.post(self.base_url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise Exception(f"API request failed: {str(e)}")

    def _parse_api_response(self, api_response):
        """Parse and validate the API response"""
        if not api_response or "choices" not in api_response:
            raise Exception("Invalid API response format")
        
        content = api_response["choices"][0]["message"]["content"]
        
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            raise Exception("Failed to parse API response content as JSON")

    def _format_response(self, original_text, api_data):
        """Format the final response with all required fields"""
        corrected = api_data.get("corrected", original_text)
        
        return {
            "original": original_text,
            "corrected": corrected,
            "score": self._calculate_score(original_text, corrected),
            "explanation": {
                "english": api_data.get("english_explanation", "No explanation generated"),
                "telugu": api_data.get("telugu_explanation", "వివరణ ఉత్పత్తి చేయబడలేదు"),
                "pronunciation": api_data.get("pronunciation_guide", "No pronunciation guide provided")
            },
            "errors": api_data.get("errors", []),
            "error_types": api_data.get("error_types", []),
            "status": "success"
        }

    def _create_error_response(self, message):
        """Create an error response"""
        return {
            "error": message,
            "status": "error"
        }

    def _calculate_score(self, original, corrected):
        """Calculate similarity score with error weighting"""
        if original == corrected:
            return 100
            
        base_score = int(SequenceMatcher(None, original, corrected).ratio() * 100)
        return max(0, min(100, base_score - 10))  # Simple penalty for any correction

# Custom CSS for styling with enhanced visuals
custom_css = """
:root {
    --primary: #4a2c82;
    --secondary: #764ba2;
    --accent: #ff5e62;
    --light: #f8f9fa;
    --dark: #343a40;
    --success: #28a745;
    --info: #17a2b8;
    --warning: #ffc107;
    --danger: #dc3545;
}

.gradio-container {
    font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    max-width: 1200px !important;
    margin: 0 auto !important;
}

.header {
    text-align: center;
    padding: 30px;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    border-radius: 15px;
    margin-bottom: 25px;
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    position: relative;
    overflow: hidden;
}

.header::before {
    content: "";
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
    transform: rotate(30deg);
}

.header h1 {
    font-size: 2.5rem;
    margin-bottom: 0.5rem;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.header h2 {
    font-size: 1.5rem;
    font-weight: 400;
    margin-bottom: 1rem;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
}

.quote {
    font-style: italic;
    font-size: 1.1rem;
    opacity: 0.9;
    margin-top: 1rem;
}

.section {
    background-color: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin-bottom: 25px;
    border: 1px solid rgba(0,0,0,0.05);
}

.section-title {
    color: var(--primary);
    margin-top: 0;
    margin-bottom: 20px;
    font-weight: 600;
    font-size: 1.4rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-title i {
    font-size: 1.6rem;
}

.instruction-box {
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    border-left: 5px solid var(--primary);
}

.instruction-box h3 {
    color: var(--primary) !important;
    margin-top: 0;
    font-size: 1.2rem;
}

.instruction-text {
    font-size: 16px;
    line-height: 1.7;
    color: #000000 !important;
}

.instruction-text ol {
    color: #000000 !important;
    padding-left: 20px;
}

.instruction-text li {
    margin-bottom: 10px;
    color: #000000 !important;
}

.button {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 12px 24px !important;
    font-weight: 600 !important;
    font-size: 16px !important;
    margin: 5px !important;
    transition: all 0.3s ease !important;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1) !important;
}

.button:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 7px 14px rgba(0,0,0,0.15) !important;
}

.record-btn {
    background: linear-gradient(135deg, #ff5e62 0%, #ff9966 100%) !important;
}

.stop-btn {
    background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%) !important;
}

.analyze-btn {
    background: linear-gradient(135deg, #28a745 0%, #5cb85c 100%) !important;
}

.clear-btn {
    background: linear-gradient(135deg, #6c757d 0%, #495057 100%) !important;
}

.status-box {
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: 600;
    font-size: 16px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.recording-status {
    background-color: #fff3f3;
    color: #d32f2f;
    border: 1px solid #ffcdd2;
}

.ready-status {
    background-color: #f0fff4;
    color: #28a745;
    border: 1px solid #c3e6cb;
}

.transcription-box, .grammar-box {
    background-color: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    margin-bottom: 20px;
    border: 1px solid rgba(0,0,0,0.05);
}

.result-title {
    color: var(--primary);
    font-weight: 600;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.score-display {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 20px 0;
}

.score-circle {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: conic-gradient(var(--success) 0% var(--percentage), #e9ecef var(--percentage) 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    position: relative;
}

.score-circle::before {
    content: "";
    position: absolute;
    width: 90px;
    height: 90px;
    border-radius: 50%;
    background: white;
}

.score-value {
    font-size: 2rem;
    font-weight: 700;
    color: var(--dark);
    z-index: 1;
}

.score-label {
    text-align: center;
    margin-top: 10px;
    font-weight: 600;
    color: var(--dark);
}

.error-item {
    padding: 12px;
    margin-bottom: 10px;
    background-color: #fff8f8;
    border-left: 4px solid var(--danger);
    border-radius: 4px;
    color: #000000 !important;
}

.explanation-box {
    background-color: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    margin-top: 15px;
    border-left: 4px solid var(--info);
}

.explanation-box p {
    color: #000000 !important;
}

.explanation-title {
    font-weight: 600;
    color: var(--info);
    margin-bottom: 10px;
}

.pronunciation-box {
    background-color: #f0f8ff;
    padding: 15px;
    border-radius: 8px;
    margin-top: 15px;
    border-left: 4px solid var(--secondary);
}

.pronunciation-title {
    font-weight: 600;
    color: var(--secondary);
    margin-bottom: 10px;
}

.footer {
    text-align: center;
    margin-top: 30px;
    padding: 20px;
    color: #6c757d;
    font-size: 0.9rem;
}

/* Add some icons using Unicode */
.icon-mic::before { content: "\\1F3A4"; }
.icon-stop::before { content: "\\23F9"; }
.icon-play::before { content: "\\25B6"; }
.icon-clear::before { content: "\\1F5D1"; }
.icon-analyze::before { content: "\\1F4DD"; }
.icon-info::before { content: "\\2139"; }
.icon-success::before { content: "\\2714"; }
.icon-error::before { content: "\\26A0"; }
"""

def clean_transcription(text):
    """Clean the transcription by removing special tokens and extra spaces."""
    text = re.sub(r'<s>', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def audio_callback(indata, frames, time, status):
    """Callback function for audio stream."""
    if is_recording:
        audio_queue.put(indata.copy())

def start_recording():
    """Start recording audio."""
    global is_recording
    is_recording = True
    audio_queue.queue.clear()
    
    # Start audio stream
    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype=np.int16,
        callback=audio_callback
    )
    stream.start()
    
    # Collect audio chunks in a separate thread
    def record_audio():
        audio_data = []
        while is_recording:
            try:
                data = audio_queue.get(timeout=1)
                audio_data.append(data)
            except queue.Empty:
                continue
        
        # Combine all chunks
        if audio_data:
            audio_data = np.concatenate(audio_data)
            filename = "recorded_audio.wav"
            write(filename, SAMPLE_RATE, audio_data)
            return filename
        return None
    
    recording_thread = threading.Thread(target=record_audio)
    recording_thread.start()
    
    return stream, recording_thread

def stop_recording(stream, recording_thread):
    """Stop recording audio."""
    global is_recording
    is_recording = False
    recording_thread.join()
    stream.stop()
    stream.close()
    return "recorded_audio.wav"

def speech_to_text(audio_file):
    """Convert speech to text using the Telugu ASR model."""
    try:
        # Load audio file
        speech_array, sampling_rate = torchaudio.load(audio_file)
        
        # Resample if needed
        if sampling_rate != SAMPLE_RATE:
            resampler = torchaudio.transforms.Resample(sampling_rate, SAMPLE_RATE)
            speech_array = resampler(speech_array)
        
        # Process audio
        input_values = processor(speech_array[0].numpy(), return_tensors="pt", sampling_rate=SAMPLE_RATE).input_values
        
        # Get logits
        with torch.no_grad():
            logits = model(input_values).logits
        
        # Decode
        predicted_ids = torch.argmax(logits, dim=-1)
        transcription = processor.batch_decode(predicted_ids)[0]
        
        return clean_transcription(transcription)
    except Exception as e:
        print(f"Error in speech_to_text: {str(e)}")
        return "ప్రతిబింబించడంలో లోపం ఏర్పడింది (Error in transcription)"

def text_to_speech(text, lang='te'):
    """Convert text to speech for playback."""
    if not text.strip():
        return None
    
    try:
        tts = gTTS(text=text, lang=lang, slow=False)
        audio_file = "output_tts.mp3"
        tts.save(audio_file)
        return audio_file
    except Exception as e:
        print(f"Error in text_to_speech: {str(e)}")
        return None

def create_score_image(score):
    """Create a circular score visualization"""
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.axis('equal')
    
    # Create a circle
    wedge, _ = ax.pie([score, 100-score], colors=['#28a745', '#e9ecef'], startangle=90, 
                      wedgeprops=dict(width=0.3))
    
    # Add center text
    ax.text(0, 0, f"{score}", ha='center', va='center', fontsize=24, fontweight='bold')
    
    # Save to buffer
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=100, bbox_inches='tight', transparent=True)
    plt.close(fig)
    buf.seek(0)
    
    # Convert to base64
    img_str = base64.b64encode(buf.read()).decode('utf-8')
    return f"data:image/png;base64,{img_str}"

def analyze_grammar(text):
    """Analyze grammar and return formatted results"""
    if not text.strip():
        return None, None, None, None, None, None, None
    
    analyzer = TeluguGrammarAnalyzer(MISTRAL_API_KEY)
    result = analyzer.analyze(text)
    
    if "error" in result:
        return None, None, None, None, None, f"Error: {result['error']}", None
    
    # Create score visualization
    score_img = create_score_image(result["score"])
    
    # Format errors
    errors_html = ""
    if result["errors"]:
        errors_html = "<div class='error-list'>"
        for error in result["errors"]:
            errors_html += f"<div class='error-item'><span class='icon-error'></span> {error}</div>"
        errors_html += "</div>"
    else:
        errors_html = "<div style='color: var(--success); font-weight: 600;'><span class='icon-success'></span> No grammar errors found!</div>"
    
    # Format explanations
    explanation_html = f"""
    <div class='explanation-box'>
        <div class='explanation-title'>English Explanation</div>
        <p>{result['explanation']['english']}</p>
    </div>
    <div class='explanation-box'>
        <div class='explanation-title'>తెలుగు వివరణ (Telugu Explanation)</div>
        <p>{result['explanation']['telugu']}</p>
    </div>
    """
    
    # Format pronunciation guide
    pronunciation_html = f"""
    <div class='pronunciation-box'>
        <div class='pronunciation-title'>ఉచ్చారణ సూచనలు / Pronunciation Guide</div>
        <p>{result['explanation']['pronunciation']}</p>
    </div>
    """
    
    return (
        result["corrected"], 
        score_img, 
        errors_html, 
        explanation_html, 
        pronunciation_html,
        result["score"],
        text_to_speech(result["corrected"])  # Generate TTS for corrected sentence
    )

# Create the interface
with gr.Blocks(css=custom_css, title="Vidyalaya - AI Powered Telugu Learning") as demo:
    # Store recording state in Gradio's state
    recording_state = gr.State({
        "stream": None,
        "thread": None,
        "is_recording": False
    })
    
    # Header with logo and motivational quote
    with gr.Column(elem_classes=["header"]):
        gr.Markdown("""
        <h1>విద్యాలయ - AI పవర్డ్ తెలుగు భాషా అభ్యాస వేదిక</h1>
        <h2>Vidyalaya - AI Powered Telugu Language Learning Platform</h2>
        <div class="quote">
            "భాష నేర్చుకోవడం అనేది ఒక కొత్త ప్రపంచాన్ని తెరుచుకోవడం"<br>
            "Learning a language is opening a door to a new world"
        </div>
        """)
    
    # Main content
    with gr.Column():
        # Instruction Section
        with gr.Column(elem_classes=["section"]):
            gr.Markdown("""
            <div class="section-title">
                <span class="icon-info"></span>
                సూచనలు / Instructions
            </div>
            <div class="instruction-box">
                <div class="instruction-text">
                <ol>
                    <li>మైక్రోఫోన్ బటన్ పై క్లిక్ చేయండి మరియు తెలుగులో మాట్లాడండి (Click the microphone button and speak in Telugu)</li>
                    <li>మీ మాటలు పూర్తి అయిన తర్వాత మళ్లీ బటన్ పై క్లిక్ చేయండి (Click the button again when you finish speaking)</li>
                    <li>మీ మాటలు టెక్స్ట్‌గా కనిపిస్తాయి (Your speech will appear as text)</li>
                    <li>మీరు కోరుకుంటే మీ వాక్యాన్ని వినండి (Optionally listen to your sentence)</li>
                    <li>వ్యాకరణ విశ్లేషణ కోసం "వ్యాకరణాన్ని పరీక్షించండి" బటన్ పై క్లిక్ చేయండి (Click "Test Grammar" for grammar analysis)</li>
                </ol>
                </div>
            </div>
            """)
        
        # Status indicator
        status_display = gr.Textbox(
            label="స్థితి / Status",
            value="సిద్ధంగా ఉంది / Ready",
            interactive=False,
            elem_classes=["status-box", "ready-status"]
        )
        
        # Recording Section
        with gr.Row():
            with gr.Column(min_width=400):
                with gr.Column(elem_classes=["section"]):
                    gr.Markdown("""<div class="section-title"><span class="icon-mic"></span> రికార్డింగ్ / Recording</div>""")
                    record_btn = gr.Button(
                        "🎤 మైక్రోఫోన్ ప్రారంభించండి / Start Microphone",
                        elem_classes=["button", "record-btn"]
                    )
                    audio_output = gr.Audio(
                        label="రికార్డ్ చేసిన ఆడియో / Recorded Audio",
                        visible=True
                    )
            
            with gr.Column(min_width=400):
                with gr.Column(elem_classes=["section"]):
                    gr.Markdown("""<div class="section-title"><span class="icon-play"></span> మీ మాటలు / Your Speech</div>""")
                    transcription_output = gr.Textbox(
                        label="మీ మాటలు / Your Speech", 
                        elem_classes="transcription-text",
                        interactive=False,
                        lines=3
                    )
                    with gr.Row():
                        play_btn = gr.Button(
                            "మీ వాక్యాన్ని వినండి / Listen", 
                            elem_classes=["button"]
                        )
                        analyze_btn = gr.Button(
                            "వ్యాకరణాన్ని పరీక్షించండి / Test Grammar", 
                            elem_classes=["button", "analyze-btn"]
                        )
                        clear_btn = gr.Button(
                            "క్లియర్ / Clear", 
                            elem_classes=["button", "clear-btn"]
                        )
                    playback_audio = gr.Audio(
                        label="ప్లేబ్యాక్ / Playback", 
                        visible=True
                    )
        
        # Grammar Analysis Section (initially hidden)
        with gr.Column(visible=False) as analysis_section:
            with gr.Column(elem_classes=["section"]):
                gr.Markdown("""<div class="section-title"><span class="icon-analyze"></span> వ్యాకరణ విశ్లేషణ / Grammar Analysis</div>""")
                
                with gr.Row():
                    with gr.Column(scale=1):
                        score_image = gr.HTML()
                        score_text = gr.Textbox(
                            label="స్కోరు / Score",
                            interactive=False
                        )
                    
                    with gr.Column(scale=2):
                        corrected_text = gr.Textbox(
                            label="సరిదిద్దిన వాక్యం / Corrected Sentence",
                            interactive=False
                        )
                        errors_html = gr.HTML()
                
                explanation_html = gr.HTML()
                pronunciation_html = gr.HTML()
                
                # Add TTS playback for corrected sentence
                with gr.Row():
                    corrected_audio = gr.Audio(
                        label="సరిదిద్దిన వాక్యం వినండి / Listen to Corrected Sentence",
                        visible=False
                    )
    
    # Button actions
    def toggle_recording(state):
        if not state["is_recording"]:
            # Start recording
            stream, thread = start_recording()
            new_state = {
                "stream": stream,
                "thread": thread,
                "is_recording": True
            }
            return [
                new_state,
                "🎤 రికార్డింగ్ జరుగుతోంది... / Recording...",
                "🎤 మైక్రోఫోన్ ఆపండి / Stop Microphone",
                None,
                None,
                gr.Column(visible=False)  # Hide analysis section
            ]
        else:
            # Stop recording
            filename = stop_recording(state["stream"], state["thread"])
            new_state = {
                "stream": None,
                "thread": None,
                "is_recording": False
            }
            
            # Get transcription
            transcription = speech_to_text(filename)
            
            return [
                new_state,
                "సిద్ధంగా ఉంది / Ready",
                "🎤 మైక్రోఫోన్ ప్రారంభించండి / Start Microphone",
                filename,
                transcription,
                gr.Column(visible=False)  # Hide analysis section
            ]
    
    def show_analysis(text):
        if not text.strip():
            return [
                None, None, None, None, None, None, None,
                gr.Column(visible=False),
                None
            ]
        
        corrected, score_img, errors, explanation, pronunciation, score, tts_file = analyze_grammar(text)
        
        if corrected is None:
            return [
                None, None, None, None, None, None, None,
                gr.Column(visible=False),
                None
            ]
        
        return [
            corrected,
            f"""<div class="score-display"><div class="score-circle" style="--percentage:{score}%"><div class="score-value">{score}</div></div></div>""",
            errors,
            explanation,
            pronunciation,
            f"{score}%",
            gr.Column(visible=True),
            tts_file if tts_file else None
        ]
    
    record_btn.click(
        fn=toggle_recording,
        inputs=[recording_state],
        outputs=[
            recording_state,
            status_display,
            record_btn,
            audio_output,
            transcription_output,
            analysis_section
        ],
        queue=False
    )
    
    play_btn.click(
        fn=text_to_speech,
        inputs=transcription_output,
        outputs=playback_audio,
        queue=True
    )
    
    analyze_btn.click(
        fn=show_analysis,
        inputs=transcription_output,
        outputs=[
            corrected_text,
            score_image,
            errors_html,
            explanation_html,
            pronunciation_html,
            score_text,
            analysis_section,
            corrected_audio
        ],
        queue=True
    )
    
    clear_btn.click(
        fn=lambda: ["", None, None, gr.Column(visible=False), None],
        outputs=[transcription_output, audio_output, playback_audio, analysis_section, corrected_audio],
        queue=False
    )

    # Footer
    gr.Markdown("""
    <div class="footer">
        విద్యాలయ - తెలుగు భాషా అభ్యాస వేదిక | © 2023 AI పవర్డ్ భాషా అభ్యాసం<br>
        Vidyalaya - Telugu Language Learning Platform | © 2023 AI Powered Language Learning
    </div>
    """)

# Launch the interface
if __name__ == "__main__":
    demo.launch(server_port=7865, server_name="127.0.0.1")