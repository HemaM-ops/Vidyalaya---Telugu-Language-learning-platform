// server.cjs
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const axios = require('axios');
require('dotenv').config();

const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json());

app.post('/api/telugu-chat', async (req, res) => {
  const userMessage = req.body.message;

  try {
    const response = await axios.post(
      'https://api.mistral.ai/v1/chat/completions',
      {
        model: 'mistral-medium',
        messages: [
          {
            role: 'system',
            content:
              "You are a friendly and knowledgeable Telugu language tutor. The user may ask questions in English or in Telugu (native script or transliterated using English letters).Your job is to: 1. Understand the user's intent, even if Telugu words are written in English letters (transliteration). 2. Reply **first in proper Telugu** with clear and accurate information. 3. Then provide an **English explanation** to help learners understand. 4. Keep the tone warm, supportive, and encouraging. 5.Help with vocabulary, grammar, pronunciation,translation and conversation. Example:User: What is the meaning of 'manassu'? Response:మనస్సు అంటే మనసు లేదా మనోభావాలు. 'Manassu' means the mind or thoughts. It refers to the emotional and mental state of a person. If the user asks for phrases or examples, give simple and practical sentences in Telugu first, then translate them into English."

          },
          {
            role: 'user',
            content: userMessage
          }
        ]
      },
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${process.env.MISTRAL_API_KEY}`
        }
      }
    );

    const assistantReply = response.data.choices[0].message.content;
    res.json({ reply: assistantReply });
  } catch (error) {
    console.error('Mistral Error:', error?.response?.data || error.message);
    res.status(500).json({ reply: 'Error contacting language model. Please try again later.' });
  }
});

app.listen(port, () => {
  console.log(`✅ Server running at http://localhost:${port}`);
});
