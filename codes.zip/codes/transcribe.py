import torch
import torchaudio
from transformers import Wav2Vec2Processor, Wav2Vec2ForCTC
import sounddevice as sd
import numpy as np
from scipy.io.wavfile import write
import gradio as gr
import time
import wave
from gtts import gTTS
import os
import re
import queue
import threading

# Load the Telugu ASR model and processor
model_name = "Harveenchadha/vakyansh-wav2vec2-telugu-tem-100"
processor = Wav2Vec2Processor.from_pretrained(model_name)
model = Wav2Vec2ForCTC.from_pretrained(model_name)

# Parameters
SAMPLE_RATE = 16000
audio_queue = queue.Queue()
is_recording = False

# Custom CSS for styling
custom_css = """
.gradio-container {
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}
.header {
    text-align: center;
    padding: 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 10px;
    margin-bottom: 20px;
}
.instruction-box {
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    border-left: 5px solid var(--primary);
}

.instruction-box h3 {
    color: var(--primary) !important;
    margin-top: 0;
    font-size: 1.2rem;
}

.instruction-text {
    font-size: 16px;
    line-height: 1.7;
    color: #000000 !important;  /* Pure black */
    /* Alternative dark blue option: color: #000080 !important; */
}

.instruction-text ol {
    color: #000000 !important;  /* Ensure ordered list text is black */
    padding-left: 20px;
}

.instruction-text li {
    margin-bottom: 10px;
    color: #000000 !important;  /* Ensure list items are black */
}
.result-box {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    margin-top: 20px;
}
.button {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white !important;
    border: none;
    border-radius: 5px;
    padding: 12px 24px;
    font-weight: bold;
    font-size: 16px;
    margin: 5px;
}
.button:hover {
    background: linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%);
}
.record-btn {
    background: linear-gradient(135deg, #ff5e62 0%, #ff9966 100%) !important;
}
.stop-btn {
    background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%) !important;
}
.transcription-text {
    font-size: 18px;
    color: #2d3748;
    font-weight: 500;
}
.status-box {
    padding: 12px;
    border-radius: 5px;
    margin-bottom: 15px;
    text-align: center;
    font-weight: bold;
    font-size: 16px;
}
.recording-status {
    background-color: #ffebee;
    color: #d32f2f;
    border: 1px solid #ef9a9a;
}
.ready-status {
    background-color: #e8f5e9;
    color: #388e3c;
    border: 1px solid #a5d6a7;
}
"""

def clean_transcription(text):
    """Clean the transcription by removing special tokens and extra spaces."""
    text = re.sub(r'<s>', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def audio_callback(indata, frames, time, status):
    """Callback function for audio stream."""
    if is_recording:
        audio_queue.put(indata.copy())

def start_recording():
    """Start recording audio."""
    global is_recording
    is_recording = True
    audio_queue.queue.clear()
    
    # Start audio stream
    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype=np.int16,
        callback=audio_callback
    )
    stream.start()
    
    # Collect audio chunks in a separate thread
    def record_audio():
        audio_data = []
        while is_recording:
            try:
                data = audio_queue.get(timeout=1)
                audio_data.append(data)
            except queue.Empty:
                continue
        
        # Combine all chunks
        if audio_data:
            audio_data = np.concatenate(audio_data)
            filename = "recorded_audio.wav"
            write(filename, SAMPLE_RATE, audio_data)
            return filename
        return None
    
    recording_thread = threading.Thread(target=record_audio)
    recording_thread.start()
    
    return stream, recording_thread

def stop_recording(stream, recording_thread):
    """Stop recording audio."""
    global is_recording
    is_recording = False
    recording_thread.join()
    stream.stop()
    stream.close()
    return "recorded_audio.wav"

def speech_to_text(audio_file):
    """Convert speech to text using the Telugu ASR model."""
    try:
        # Load audio file
        speech_array, sampling_rate = torchaudio.load(audio_file)
        
        # Resample if needed
        if sampling_rate != SAMPLE_RATE:
            resampler = torchaudio.transforms.Resample(sampling_rate, SAMPLE_RATE)
            speech_array = resampler(speech_array)
        
        # Process audio
        input_values = processor(speech_array[0].numpy(), return_tensors="pt", sampling_rate=SAMPLE_RATE).input_values
        
        # Get logits
        with torch.no_grad():
            logits = model(input_values).logits
        
        # Decode
        predicted_ids = torch.argmax(logits, dim=-1)
        transcription = processor.batch_decode(predicted_ids)[0]
        
        return clean_transcription(transcription)
    except Exception as e:
        print(f"Error in speech_to_text: {str(e)}")
        return "ప్రతిబింబించడంలో లోపం ఏర్పడింది (Error in transcription)"

def text_to_speech(text, lang='te'):
    """Convert text to speech for playback."""
    if not text.strip():
        return None
    
    try:
        tts = gTTS(text=text, lang=lang, slow=False)
        audio_file = "output_proper.mp3"
        tts.save(audio_file)
        return audio_file
    except Exception as e:
        print(f"Error in text_to_speech: {str(e)}")
        return None

# Create the interface
with gr.Blocks(css=custom_css) as demo:
    # Store recording state in Gradio's state
    recording_state = gr.State({
        "stream": None,
        "thread": None,
        "is_recording": False
    })
    
    with gr.Column():
        # Header
        gr.Markdown("""
        <div class="header">
            <h1>తెలుగు భాషా అభ్యాస వేదిక</h1>
            <h2>Telugu Language Learning Platform</h2>
        </div>
        """)
        
        # Instruction Section
        with gr.Column(elem_classes="instruction-box"):
            gr.Markdown("""
            <h3>సూచనలు (Instructions)</h3>
            <div class="instruction-text">
            <ol>
                <li><strong>మైక్రోఫోన్ బటన్</strong> పై క్లిక్ చేయండి మరియు తెలుగులో మాట్లాడండి (Click the microphone button and speak in Telugu)</li>
                <li>మీ మాటలు పూర్తి అయిన తర్వాత మళ్లీ బటన్ పై క్లిక్ చేయండి (Click the button again when you finish speaking)</li>
                <li>మీ మాటలు టెక్స్ట్‌గా కనిపిస్తాయి (Your speech will appear as text)</li>
                <li>మీరు కోరుకుంటే మీ వాక్యాన్ని వినండి (Optionally listen to your sentence)</li>
            </ol>
            </div>
            """)
        
        # Status indicator
        status_display = gr.Textbox(
            label="స్థితి (Status)",
            value="సిద్ధంగా ఉంది (Ready)",
            interactive=False,
            elem_classes=["status-box", "ready-status"]
        )
        
        # Recording Section
        with gr.Row():
            with gr.Column():
                record_btn = gr.Button(
                    "🎤 మైక్రోఫోన్ ప్రారంభించండి (Start Microphone)",
                    elem_classes=["button", "record-btn"]
                )
                audio_output = gr.Audio(
                    label="రికార్డ్ చేసిన ఆడియో (Recorded Audio)",
                    visible=True
                )
            with gr.Column():
                transcription_output = gr.Textbox(
                    label="మీ మాటలు (Your Speech)", 
                    elem_classes="transcription-text",
                    interactive=False
                )
                with gr.Row():
                    play_btn = gr.Button(
                        "మీ వాక్యాన్ని వినండి (Listen to your sentence)", 
                        elem_classes="button"
                    )
                    clear_btn = gr.Button("క్లియర్ (Clear)", elem_classes="button")
                playback_audio = gr.Audio(
                    label="ప్లేబ్యాక్ (Playback)", 
                    visible=True
                )
    
    # Button actions
    def toggle_recording(state):
        if not state["is_recording"]:
            # Start recording
            stream, thread = start_recording()
            new_state = {
                "stream": stream,
                "thread": thread,
                "is_recording": True
            }
            return [
                new_state,
                "🎤 రికార్డింగ్ జరుగుతోంది... (Recording...)",
                "🎤 మైక్రోఫోన్ ఆపండి (Stop Microphone)",
                None,
                None
            ]
        else:
            # Stop recording
            filename = stop_recording(state["stream"], state["thread"])
            new_state = {
                "stream": None,
                "thread": None,
                "is_recording": False
            }
            
            # Get transcription
            transcription = speech_to_text(filename)
            
            return [
                new_state,
                "సిద్ధంగా ఉంది (Ready)",
                "🎤 మైక్రోఫోన్ ప్రారంభించండి (Start Microphone)",
                filename,
                transcription
            ]
    
    record_btn.click(
        fn=toggle_recording,
        inputs=[recording_state],
        outputs=[
            recording_state,
            status_display,
            record_btn,
            audio_output,
            transcription_output
        ],
        queue=False
    )
    
    play_btn.click(
        fn=text_to_speech,
        inputs=transcription_output,
        outputs=playback_audio,
        queue=True
    )
    
    clear_btn.click(
        fn=lambda: ["", None, None],
        outputs=[transcription_output, audio_output, playback_audio],
        queue=False
    )

# Launch the interface
if __name__ == "__main__":
    demo.launch(server_port=7860, server_name="127.0.0.1")